import React, { Component } from "react";

import TaxCalculator from "./TaxCalculator";

class App extends Component {
  render() {
    return (
      <div>
        <TaxCalculator />
      </div>
    );
  }
}

export default App;
